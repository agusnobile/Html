<?php
$nombre = $_POST['nombre'];
$contraseña = $_POST['contraseña'];
echo 'Ingresaste el nombre: '.$nombre;
echo 'Tu contraseña es: '.$contraseña;
?>