<?php

$nombre = $_POST['nombre'];
$contraseña = $_POST['constraseña'];
echo 'Hola tu nombre es'.$nombre;
echo 'Hola tu contraseña es'.$contraseña;



?>